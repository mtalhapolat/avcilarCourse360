<html lang="en" data-bs-theme="auto">
<head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.111.3">
    <title>SMS Kuyruğu</title>
    <link rel="icon" href="https://beyoglu.bel.tr/wp-content/uploads/2021/02/favicon.ico" sizes="192x192">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/starter-template/">


    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">


</head>
<body style="background-color:#f8f2ed">


<?php


echo '<br>';




echo '<br>';
echo "---------------";
echo '<br>';


?>

</body>
</html>
